
window.alert("Welcome to my website!");
function select_wrong(){
    window.alert("Oops, try again!");
}
function select_right(){
    window.alert("Great job, that's exactly right! ");
}